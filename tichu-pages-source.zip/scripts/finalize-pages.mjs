import { readdirSync, readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";
const base = process.env.NEXT_PUBLIC_BASE_PATH || "";
function visit(dir) { for (const entry of readdirSync(dir, {withFileTypes:true})) { const p=join(dir,entry.name); if(entry.isDirectory()) visit(p); else if(p.endsWith(".css")) writeFileSync(p,readFileSync(p,"utf8").replaceAll("/fonts/PretendardVariable.woff2",`${base}/fonts/PretendardVariable.woff2`)); } }
visit("out"); writeFileSync("out/.nojekyll", "");
