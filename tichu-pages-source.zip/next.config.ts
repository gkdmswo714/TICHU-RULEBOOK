import type { NextConfig } from "next";
const config: NextConfig = {
  devIndicators: false,
  output: "export",
  basePath: process.env.NEXT_PUBLIC_BASE_PATH || "",
  images: { unoptimized: true },
  distDir: process.env.TICHU_BUILD_DIR || ".next",
  outputFileTracingRoot: process.cwd(),
  turbopack: { root: process.cwd() },
  experimental: { cpus: 2 },
};
export default config;
